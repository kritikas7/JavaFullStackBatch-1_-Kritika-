package com.verizon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import com.verizon.service.ProductService;
@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	 @PostMapping("/product")
	    public String addProductDetails(@RequestBody Product product) {
	        return productService.addProduct(product);
	    }

	    @GetMapping("/product")
	    public ResponseEntity<List<Product>> getAllProducts() {
	        List<Product> products = productService.getProducts();
	        return new ResponseEntity<>(products, HttpStatus.OK);
	    }

	    @GetMapping("/product/{pid}")
	    public ResponseEntity<Product> getProduct(@PathVariable Integer pid) {
	        try {
	            Product product = productService.getProduct(pid);
	            return new ResponseEntity(product, HttpStatus.OK);
	        } catch (ProductNotFoundException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	@GetMapping("/product/{low}/{high}")
	public List<Product> getProductBetweenPriceRange(@RequestParam Integer low, @RequestParam Integer high) {
        List<Product> products = productService.getAllProductsBetweenLowHigh(low, high);
        return (List<Product>) new ResponseEntity(products, HttpStatus.OK);
    }
	
	@PutMapping("/product/{pid}") 
	public Product updateProductDetails(@PathVariable("pid") Integer pid,@RequestBody Product product) {
		
		return productService.updateProduct(pid, product); 
	}
	
	@DeleteMapping("/product/{pid}") 
public Product deleteProductDetails(@PathVariable("pid") Integer pid) {
		
		return  productService.deleteProduct(pid);

	}
	
}
