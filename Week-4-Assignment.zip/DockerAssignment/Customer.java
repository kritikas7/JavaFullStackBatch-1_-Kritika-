  
  class Customer{
    String name;
  
   Customer(String name) {
     this.name=name;
   }

  void displayCustomerName() {
  System.out.println("Customer Nmae :"+ name);
  }
 public static void main(String args[]) {
   Customer c=new Customer("VerizonUSer");
     //call function to display customer name
c.displayCustomerName();
}
}